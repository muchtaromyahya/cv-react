import React from 'react';

import './App.css';

function App() {
  return (
    <div className="App">
      <h1>My First Heading</h1>
      <p>My first paragraph.</p>
    </div>
  );
}

export default App;
